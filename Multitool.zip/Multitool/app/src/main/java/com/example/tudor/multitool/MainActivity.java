package com.example.tudor.multitool;

import android.content.Context;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText ee = (EditText) findViewById(R.id.editText1);
        ee.setVisibility(View.INVISIBLE);
        Button b = (Button) findViewById(R.id.button6);
        b.setVisibility(View.INVISIBLE);
        b = (Button) findViewById(R.id.start);
        b.setVisibility(View.INVISIBLE);
        b = (Button) findViewById(R.id.stop);
        b.setVisibility(View.INVISIBLE);
        Chronometer c = (Chronometer) findViewById(R.id.chronometer);
        c.setVisibility(View.INVISIBLE);
        TextView t = (TextView) findViewById(R.id.time);
        t.setVisibility(View.INVISIBLE);
        boolean ok = fileExistance("list");
        if(ok == false)
        {
            File file = new File(this.getFilesDir(), "list");
        }
        else
        {
            int ch;
            StringBuffer fileContent = new StringBuffer("");
            FileInputStream fis;
            try {
                fis = this.openFileInput("list");
                try {
                    while( (ch = fis.read()) != -1)
                        fileContent.append((char)ch);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

            String data = new String(fileContent);
            ee.setText(data);
        }
    }

    public boolean fileExistance(String fname){
        File file = getBaseContext().getFileStreamPath(fname);
        return file.exists();
    }

    double a;
    public void start(View view)
    {
        Chronometer c = (Chronometer) findViewById(R.id.chronometer);
        c.setBase(SystemClock.elapsedRealtime());
        double StartTime = System.currentTimeMillis();
        a=StartTime;
        c.start();
    }
    public void chronometer(View view)
    {
        Button b = (Button) findViewById(R.id.button);
        b.setVisibility(View.INVISIBLE);
        b = (Button) findViewById(R.id.button4);
        b.setVisibility(View.INVISIBLE);
        b = (Button) findViewById(R.id.button5);
        b.setVisibility(View.INVISIBLE);
        b = (Button) findViewById(R.id.button6);
        b.setVisibility(View.VISIBLE);
        b = (Button) findViewById(R.id.button3);
        b.setVisibility(View.INVISIBLE);
        b = (Button) findViewById(R.id.start);
        b.setVisibility(View.VISIBLE);
        Chronometer c = (Chronometer) findViewById(R.id.chronometer);
        c.setVisibility(View.VISIBLE);
        b = (Button) findViewById(R.id.stop);
        b.setVisibility(View.VISIBLE);
    }
    public void stop(View view)
    {
        Chronometer c = (Chronometer) findViewById(R.id.chronometer);
        c.stop();
        TextView t = (TextView) findViewById(R.id.time);
        String s= String.valueOf(System.currentTimeMillis()-a);
        t.setText(s);
        t.setVisibility(View.VISIBLE);
    }


    public void lista(View view)
    {
        Button b = (Button) findViewById(R.id.button);
        b.setVisibility(View.INVISIBLE);
        b = (Button) findViewById(R.id.button3);
        b.setVisibility(View.INVISIBLE);
        b = (Button) findViewById(R.id.button4);
        b.setVisibility(View.INVISIBLE);
        b = (Button) findViewById(R.id.button5);
        b.setVisibility(View.INVISIBLE);
        b = (Button) findViewById(R.id.button6);
        b.setVisibility(View.VISIBLE);
        EditText e = (EditText) findViewById(R.id.editText1);
        e.setVisibility(View.VISIBLE);
    }
    public void back(View view)
    {
        EditText ee = (EditText) findViewById(R.id.editText1);
        Button b = (Button) findViewById(R.id.button);
        b.setVisibility(View.VISIBLE);
        b = (Button) findViewById(R.id.button3);
        b.setVisibility(View.VISIBLE);
        b = (Button) findViewById(R.id.button4);
        b.setVisibility(View.VISIBLE);
        b = (Button) findViewById(R.id.button5);
        b.setVisibility(View.VISIBLE);
        b = (Button) findViewById(R.id.button6);
        b.setVisibility(View.INVISIBLE);
        b = (Button) findViewById(R.id.start);
        if (ee.getVisibility() == View.VISIBLE)
            ee.setVisibility(View.INVISIBLE);
            else if (b.getVisibility() == View.VISIBLE)
            {
                Chronometer c = (Chronometer) findViewById(R.id.chronometer);
                c.setVisibility(View.INVISIBLE);
                b.setVisibility(View.INVISIBLE);
                b = (Button) findViewById(R.id.stop);
                b.setVisibility(View.INVISIBLE);
                TextView t = (TextView) findViewById(R.id.time);
                t.setVisibility(View.INVISIBLE);
            }
        String FILENAME ="list";
        String strMsgToSave = ee.getText().toString();
        FileOutputStream fos;
        try
        {
            fos = this.openFileOutput(FILENAME, Context.MODE_PRIVATE);
            try
            {
                fos.write( strMsgToSave.getBytes() );
                fos.close();

            }
            catch (IOException e)
            {
                e.printStackTrace();
            }

        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
    }
}
